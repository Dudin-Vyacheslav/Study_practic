new Swiper('.main', {
    loop: true,
    autoplay: {

        delay: 10000
    }

});

new Swiper('.mail2', {
    slidesPerView: 3,
    spaceBetween: 30,
    loop: true,
    loopFillGroupWithBlank: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,

    }});
